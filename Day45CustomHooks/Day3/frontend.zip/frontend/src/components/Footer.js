const Footer = () => {
    return (
        <div className="row bg-warning"> 
            <h1>Footer</h1>
        </div>
     );
}
 
export default Footer;